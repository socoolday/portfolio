<?php include "./lib/meta.php"; ?>
<?php include "./lib/sub_head.php"; ?>

    <div class="sub_title">
        <h2>QR 결제</h2>
        <button type="button">QR가이드</button>
    </div>
    <div class="sub_single_con">
        <div class="pay_btn_b">
            <ul>
                <li><button type="button" class="bg_blue_1"><img src="./images/icon_18.png" alt=""><span>QR 스캔</span></button></li>
                <li><button type="button" class="bg_blue_1"><img src="./images/icon_19.png" alt=""><span>QR 결제</span></button></li>
            </ul>
        </div>
    </div>







<?php include "./lib/footer.php"; ?>