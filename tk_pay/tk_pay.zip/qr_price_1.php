<?php include "./lib/meta.php"; ?>
<?php include "./lib/sub_head.php"; ?>

    <div class="sub_title">
        <h2>QR 결제</h2>
        <button type="button">QR가이드</button>
    </div>
    <div class="input_group">
        
        <div class="input_btn">
            <button type="button" class="bg_blue_1"><img src="./images/icon_12.png" alt="">  QR 스캔</button>
            <button type="button" class="bg_blue_1"><img src="./images/icon_12.png" alt="">   QR 결제</button>
        </div>
    </div>







<?php include "./lib/footer.php"; ?>