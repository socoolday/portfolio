    <div class="fix_menu">
        <ul>
            <li>
                <a href="./index.php"><img src="./images/icon_8.png" alt=""></a>
            </li>
            <li>
                <a href="./menu.php"><img src="./images/icon_9.png" alt=""></a>
            </li>
            <li class="quick_center">
                <a href="" class="bg_blue_1"><img src="./images/icon_12.png" alt=""></a>
            </li>
            <li>
                <a href=""><img src="./images/icon_10.png" alt=""></a>
            </li>
            <li>
                <a href="./my_page.php"><img src="./images/icon_11.png" alt=""></a>
            </li>
        </ul>
    </div>