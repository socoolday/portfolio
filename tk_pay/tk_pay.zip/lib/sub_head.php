<div class="wrap">
    <?php include "./lib/fixmenu.php"; ?>
    <div class="sub_head">
        <a href=""><img src="./images/left_l.png" alt=""></a>
        <div class="head_info">
            <p>Sample 님</p>
            <button type="button"><img src="./images/icon_1.png" alt=""></button>
        </div>
    </div>