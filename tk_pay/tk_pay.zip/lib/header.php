<!--skin header:s-->
<div class="wrap">
    <?php include "./lib/fixmenu.php"; ?>
    <div class="main_head">
        <a href=""><img src="./images/logo.png" alt=""></a>
        <div class="head_info">
            <p>Sample 님</p>
            <button type="button"><img src="./images/icon_1.png" alt=""></button>
        </div>
    </div>