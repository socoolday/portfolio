<?php include "./lib/meta.php"; ?>
<?php include "./lib/sub_head.php"; ?>

    <div class="sub_title">
        <h2>TK코인 전환</h2>
    </div>
    <div class="tc_chage">
        <div class="input_btn">
            <button type="button" class="bg_blue_1"><img src="./images/icon_25.png" alt="">지갑생성</button>
        </div>
    </div>




<?php include "./lib/footer.php"; ?>