<?php include "./lib/meta.php"; ?>
<?php include "./lib/fixmenu.php"; ?>

    <div class="menu">
        <h2>menu</h2>
        <ul>
            <li>
                <a href=""><img src="./images/icon_14.png" alt=""><p>로그아웃</p></a>
            </li>
            <li>
                <a href="./my_page.php"><img src="./images/icon_15.png" alt=""><p>마이페이지</p></a>
            </li>
            <li>
                <a href="./notice.php"><img src="./images/icon_16.png" alt=""><p>공지사항</p></a>
            </li>
            <li>
                <a href="./qna.php"><img src="./images/icon_17.png" alt=""><p>Q&amp;A</p></a>
            </li>
        </ul>
    </div>
</div>