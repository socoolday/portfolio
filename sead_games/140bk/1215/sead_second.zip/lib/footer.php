<div class="footer">
    <div class="con">
        <div class="foot_L">
<!--            <a href=""><img src="./images/foot_logo.png" alt=""></a>-->
        </div>
    </div>
</div>
</body>
</html>