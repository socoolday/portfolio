<?php include "./lib/meta.php"; ?>
<?php include "./lib/header.php"; ?>
   

<div class="wrap">
    <div class="con">
        <div class="board_view">
            <div class="board_view_cover">
                <div class="board_con">
                    <div class="user_info_board">
                        <div class="uib_img">
                            <a href="./board_view.php"><img src="./images/sm_4_img.png" alt=""></a>
                        </div>
                        <div class="uib_name_state">
                            <a href="./board_view.php">
                                <p>Name Surname</p>
                                <span>1h ago</span>
                            </a>
                        </div>
                    </div>
                    <div class="user_text">
                        <a href="">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor #incididunt ero labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco poriti laboris nisi ut aliquip ex ea commodo consequat.</a>
                    </div>
                    <div class="user_img_board">
                        <a href=""><img src="./images/b_img_1.png" alt=""></a>
                    </div>
                    <div class="user_comment_like">
                        <button type="button"><i class="xi-heart"></i> <span>10</span></button>
                        <button type="button" class="add_coment"><i class="xi-comment"></i> <span>15</span></button>
                    </div>
                </div>
                <div class="bo_v_coment">
                    <div class="bvc_b">
                        <textarea name="" id="" cols="" rows=""></textarea>
                        <button type="button" class="bvc_b_send"><i class="xi-send"></i></button>
                    </div>
                </div>
                <div class="bo_c_cover">
                    <ul>
                        <li>
                            <div class="bcc_b">
                                <div class="bcc_use_img">
                                    <a href=""><img src="./images/sm_4_img.png" alt=""></a>
                                    <div class="bunc_tit">
                                        <a href="">Name Surname</a>
                                        <p>1h ago</p>
                                    </div>
                                </div>
                                <div class="bcc_use_name_coment">
                                    <div class="bunc_coment_b">
                                        <div class="bunc_co_txt">
                                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut ero labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco poriti laboris nisi ut aliquip ex ea commodo consequat.</p>
                                        </div>
                                        <div class="bunc_bt_bt">
                                            <button type="button"><i class="xi-heart"></i> <span>609</span></button>
                                            <div class="bunc_coment_del">
                                                <button type="button" class="bcd_b_cl"><i class="xi-ellipsis-v"></i></button>
                                                <button type="button" class="bcd_btn"><i class="xi-minus-circle-o"></i>Delete</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </li>
                        <li>
                            <div class="bcc_b">
                                <div class="bcc_use_img">
                                    <a href=""><img src="./images/sm_4_img.png" alt=""></a>
                                    <div class="bunc_tit">
                                        <a href="">Name Surname</a>
                                        <p>1h ago</p>
                                    </div>
                                </div>
                                <div class="bcc_use_name_coment">
                                    <div class="bunc_coment_b">
                                        <div class="bunc_co_txt">
                                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut ero labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco poriti laboris nisi ut aliquip ex ea commodo consequat.</p>
                                        </div>
                                        <div class="bunc_bt_bt">
                                            <button type="button"><i class="xi-heart"></i> <span>609</span></button>
                                            <div class="bunc_coment_del">
                                                <button type="button" class="bcd_b_cl"><i class="xi-ellipsis-v"></i></button>
                                                <button type="button" class="bcd_btn"><i class="xi-minus-circle-o"></i>Delete</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </li>
                        <li>
                            <div class="bcc_b">
                                <div class="bcc_use_img">
                                    <a href=""><img src="./images/sm_4_img.png" alt=""></a>
                                    <div class="bunc_tit">
                                        <a href="">Name Surname</a>
                                        <p>1h ago</p>
                                    </div>
                                </div>
                                <div class="bcc_use_name_coment">
                                    <div class="bunc_coment_b">
                                        <div class="bunc_co_txt">
                                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut ero labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco poriti laboris nisi ut aliquip ex ea commodo consequat.</p>
                                        </div>
                                        <div class="bunc_bt_bt">
                                            <button type="button"><i class="xi-heart"></i> <span>609</span></button>
                                            <div class="bunc_coment_del">
                                                <button type="button" class="bcd_b_cl"><i class="xi-ellipsis-v"></i></button>
                                                <button type="button" class="bcd_btn"><i class="xi-minus-circle-o"></i>Delete</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>




<?php include "./lib/footer.php"; ?>